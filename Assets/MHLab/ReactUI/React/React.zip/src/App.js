import React from 'react';
import { hot } from "react-hot-loader";
import Dispatcher from './api/Dispatcher';
import ResourceBarsContainer from './components/ResourceBarsContainer';
import LogsContainer from './components/LogsContainer';
import InventoryContainer from './components/InventoryContainer';
import MapContainer from './components/MapContainer';
import CharacterInfoContainer from './components/CharacterInfoContainer';

const resourceBarsListStyle = {listStyle: "none"};

class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			playerSpawned: false,
		};

		var self = this;
		Dispatcher.on("player_spawned", function (payload) {
			console.log("Player spawned!");
			self.setState({
				playerSpawned: true,
			});
		});
	}

	render() {
		return (
			<div className={(this.state.playerSpawned ? "" : "hide")}>
				<ResourceBarsContainer/>
				<LogsContainer />
				<CharacterInfoContainer />
				<MapContainer />
				<InventoryContainer />
				
			</div>
		);
	}
}

export default hot(module)(App);
