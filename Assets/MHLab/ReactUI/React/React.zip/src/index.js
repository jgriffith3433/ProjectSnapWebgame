import React from 'react';
import ReactDOM from 'react-dom';
import './styles/index.less';
import App from './App';
import Dispatcher from './api/Dispatcher';

window.EngineTrigger.on("engine_event", (eventData) => {
	Dispatcher.dispatch(eventData.eventName, eventData.payload);
});
window.EngineTrigger.on("engine_log", (message) => {
	Dispatcher.dispatch("engine_log", message);
});

ReactDOM.render(<App />, document.getElementById('ui_root'));