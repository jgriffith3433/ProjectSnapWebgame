import React from 'react';
import { hot } from "react-hot-loader";
import Dispatcher from './../api/Dispatcher';

class ResourceBar extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			styles: {
				background: {
					backgroundColor: this.props.backgroundColor,
				},
				filler: {
					backgroundColor: this.props.fillerColor,
					width: this.props.filling
				}
			}
		};

		if(this.props.eventName)
		{
			var self = this;
			Dispatcher.on(this.props.eventName, function (payload) {
				self.setState({
					styles: {
						background: {
							backgroundColor: self.props.backgroundColor,
						},
						filler: {
							backgroundColor: self.props.fillerColor,
							width: "" + (100 * payload.value) + "%",
						}
					}
				});
			});
		}
	}

	render() {
		return (
			<div className="resourcebar-container">
				<div className="resourcebar-background" style={this.state.styles.background}>
					<div className="resourcebar-filling" style={this.state.styles.filler}></div>
				</div>
			</div>
		);
	}
}

export default hot(module)(ResourceBar);
