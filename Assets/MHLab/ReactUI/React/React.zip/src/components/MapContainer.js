import React from 'react';
import { hot } from "react-hot-loader";
import Dispatcher from './../api/Dispatcher';
import MapImage from './../images/map.png';

class MapContainer extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			opened: false,
		};

		var self = this;
		Dispatcher.on("toggle_map", function (payload) {
			self.setState({
				opened: !self.state.opened
			})
		});
	}

	render() {
		if(this.state.opened)
		{
			return (
				<div className="map-container">
					<div className="map-background">
						<div className="map-header">
							<div className="map-name">Test Map</div>
							<div className="close-button" onClick={(e) => Dispatcher.dispatch("toggle_map", {})}>
								<div className="close-button-inner">
									X
								</div>
							</div>
						</div>
						<div className="map-content">
							<img src={MapImage} />
						</div>
					</div>
				</div>
			);
		}
		else
		{
			return (<div></div>);
		}
	}
}

export default hot(module)(MapContainer);
