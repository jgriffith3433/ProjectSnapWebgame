import React from 'react';
import { hot } from "react-hot-loader";
import ResourceBar from './ResourceBar';

const resourceBarsListStyle = { listStyle: "none" };

class ResourceBarsContainer extends React.Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<ul style={resourceBarsListStyle}>
				<li><ResourceBar eventName="health_change" filling="100%" backgroundColor="rgb(197, 137, 133)" fillerColor="#e75045" /></li>
				<li><ResourceBar eventName="mana_change" filling="100%" backgroundColor="rgb(137, 133, 197)" fillerColor="#4545e7" /></li>
				<li><ResourceBar eventName="stamina_change" filling="100%" backgroundColor="rgb(135, 176, 137)" fillerColor="#71e745" /></li>
			</ul>
		);
	}
}

export default hot(module)(ResourceBarsContainer);
