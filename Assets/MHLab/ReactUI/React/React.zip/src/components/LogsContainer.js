import React from 'react';
import { hot } from "react-hot-loader";
import Dispatcher from './../api/Dispatcher';

var logs = [];

class LogsContainer extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			logsCounter: 0
		};

		var self = this;
		Dispatcher.on("engine_log", function (payload) {
			console.log(payload);
			logs.push(payload);
			self.setState({
				logsCounter: self.state.logsCounter + 1
			});
		});
	}

	render() {
		return (
			<div className="logs-container">
				{logs.reverse().map((log) => <div>{log}</div>)}
			</div>
		);
	}
}

export default hot(module)(LogsContainer);
