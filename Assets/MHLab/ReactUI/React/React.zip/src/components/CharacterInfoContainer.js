import React from 'react';
import { hot } from "react-hot-loader";
import Dispatcher from './../api/Dispatcher';
import CharacterImage from './../images/characterInfo.png';

class CharacterInfoContainer extends React.Component {
	constructor(props) {
		super(props);
		this.state = {

		};
	}

	render() {
		return (
			<div className="character-info-container">
				<div className="character-info-background">
					<div className="character-info-inner">
						<img src={CharacterImage} />
					</div>
				</div>
				<div className="server-information">
					W6, Ch23 - Test Map
				</div>
				<div className="map-button-container">
					<div className="map-button-background">
						<div className="map-button-inner" onClick={(e) => Dispatcher.dispatch("toggle_map", {})}>
							M
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export default hot(module)(CharacterInfoContainer);
