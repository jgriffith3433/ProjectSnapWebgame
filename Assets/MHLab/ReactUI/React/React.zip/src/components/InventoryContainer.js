import React from 'react';
import { hot } from "react-hot-loader";
import Dispatcher from './../api/Dispatcher';
import PotionImage from './../images/potion.png';

class InventoryContainer extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isPicked: false
		};

		var self = this;
		Dispatcher.on("player_picked_potion", function (payload) {
			self.setState({
				isPicked: true
			});
		});
	}

	onPotionClick()
	{
		window.FireUIEvent("player_used_potion", {});
		this.setState({
			isPicked: false
		});
	}

	render() {
		return (
			<div className="inventory-container">
				<div className="inventory-background">
					<ul className="inventory-slots">
						<li onClick={(e) => this.onPotionClick()}><img src={PotionImage} className={(this.state.isPicked) ? "" : "hide"} /></li>
					</ul>
				</div>
			</div>
		);
	}
}

export default hot(module)(InventoryContainer);
