import React from 'react';
import { hot } from "react-hot-loader";

class LogEntry extends React.Component {
	constructor(props) {
		super(props);
		this.state = {

		};
	}

	render() {
		return (
			
		);
	}
}

export default hot(module)(LogEntry);
